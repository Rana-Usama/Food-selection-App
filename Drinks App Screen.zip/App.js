import React from "react";
import { Text } from "react-native";
import LoginScreens from "./app/screens/LoginScreens";

export default function App() {
  return <LoginScreens />;
}
