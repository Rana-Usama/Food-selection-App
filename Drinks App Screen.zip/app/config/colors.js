export default colors = {
  white: "#fff",
  light: "#3b4859",
  yellow: "#f1b616",
  main: "#091a2e",
};
